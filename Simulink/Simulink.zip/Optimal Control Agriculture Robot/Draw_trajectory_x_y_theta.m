q  = out.q;
qd = out.qd;

t = q.Time;

q_data  = q.Data;
qd_data = qd.Data;

x   = q_data(:,1);
y   = q_data(:,2);
th  = q_data(:,3);

xd  = qd_data(:,1);
yd  = qd_data(:,2);
thd = qd_data(:,3);

figure('Color','w')

%% ===== x trajectory =====
subplot(3,1,1)

plot(t,x,'r','LineWidth',1.5); hold on
plot(t,xd,'b--','LineWidth',1.5)

title('Quỹ đạo x trong quá trình học điều khiển','Color','k')
ylabel('x (m)','Color','k')

lgd = legend('x','x_d');
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])

%% ===== y trajectory =====
subplot(3,1,2)

plot(t,y,'r','LineWidth',1.5); hold on
plot(t,yd,'b--','LineWidth',1.5)

title('Quỹ đạo y trong quá trình học điều khiển','Color','k')
ylabel('y (m)','Color','k')

lgd = legend('y','y_d');
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])

%% ===== theta trajectory =====
subplot(3,1,3)

plot(t,th,'r','LineWidth',1.5); hold on
plot(t,thd,'b--','LineWidth',1.5)

title('Quỹ đạo góc quay \theta trong quá trình học điều khiển','Color','k')
ylabel('\theta (rad)','Color','k')
xlabel('Time (s)','Color','k')

lgd = legend('\theta','\theta_d');
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])

%% ===== MŨI TÊN KHÔNG HIỆN TRONG LEGEND =====
x_arrow = 1200;
y_low   = interp1(t,thd,x_arrow);
y_high  = y_low + 10*pi;

% đường đứng
plot([x_arrow x_arrow],[y_low y_high], ...
    'k','LineWidth',1, ...
    'HandleVisibility','off')

% mũi tên trên
plot(x_arrow,y_high,'k^', ...
    'MarkerSize',4, ...
    'MarkerFaceColor','k', ...
    'HandleVisibility','off')

% mũi tên dưới
plot(x_arrow,y_low,'kv', ...
    'MarkerSize',4, ...
    'MarkerFaceColor','k', ...
    'HandleVisibility','off')

% chữ 2pi
text(x_arrow+15,(y_low+y_high)/2,'k2\pi', ...
    'FontSize',8, ...
    'FontWeight','bold', ...
    'Color','k');