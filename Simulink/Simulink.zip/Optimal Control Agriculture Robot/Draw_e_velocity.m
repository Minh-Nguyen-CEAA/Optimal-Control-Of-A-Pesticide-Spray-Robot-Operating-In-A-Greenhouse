figure('Color','w')
Tracking_Velocity=out.Tracking_Velocity;
plot(Tracking_Velocity.Time, Tracking_Velocity.Data(:,1),'r','LineWidth',1); hold on
plot(Tracking_Velocity.Time, Tracking_Velocity.Data(:,2),'b','LineWidth',1);

xlabel('Time (s)','Color','k')
title('e_{(v_d-v)}, e_{(\omega_d-\omega)}','Color','k')

lgd = legend('e_{(v_d-v)} (m)','e_{(\omega_d-\omega)} (rad)');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(Tracking_Velocity.Time)])   % trục time đúng tới 628