figure('Color','w')

mchange = out.m_change;
Ichange = out.I_change;

%% ===== DATA =====
t1 = mchange.Time;
m  = mchange.Data;

t2 = Ichange.Time;
I  = Ichange.Data;

%% ===== SUBPLOT 1 : m =====
subplot(2,1,1)

plot(t1,m,'r','LineWidth',1.2)

xlabel('Time (s)','Color','k')
ylabel('m (kg)','Color','k')

title('Lịch trình thay đổi khối lượng robot trong quá trình điều khiển','Color','k')

lgd = legend('m');
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(t1)])

%% ===== SUBPLOT 2 : I =====
subplot(2,1,2)

plot(t2,I,'b','LineWidth',1.2)

xlabel('Time (s)','Color','k')
ylabel('I (kg.m^2)','Color','k')

title('Lịch trình thay đổi mô men quán tính robot trong quá trình điều khiển','Color','k')

lgd = legend('I');
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(t2)])