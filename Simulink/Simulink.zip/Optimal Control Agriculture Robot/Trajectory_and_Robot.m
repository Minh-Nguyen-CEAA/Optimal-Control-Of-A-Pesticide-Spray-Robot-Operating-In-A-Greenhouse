%% ===== LẤY DATA =====
data  = qd.Data;     % Nx3 [x y theta]
t     = qd.Time;
x     = data(:,1);
y     = data(:,2);
theta = data(:,3);

%% ===== THÔNG SỐ LUỐNG =====
y0 = 1.2;      % y bắt đầu
dy = 50;       % chiều dài luống
% (x đầu, x cuối) – THEO ĐÚNG YÊU CẦU
lanes = [ ...
    0.6  1.4;
    2.2  3;
    3.8  4.6;
    5.4  6.2;
    7  7.8;
    8.6  9.4
];

%% ===== FIGURE =====
figure; hold on;
set(gcf,'Color','w');
set(gca,'Color','w');
grid on; axis equal;

%% ===== VẼ & TÔ MÀU LUỐNG =====
for i = 1:size(lanes,1)
    x1 = lanes(i,1);
    x2 = lanes(i,2);
    % tô màu luống
    patch([x1 x1 x2 x2], [y0 y0+dy y0+dy y0],...
          [0.85 0.95 0.85], ...
          'EdgeColor','none', ...
          'FaceAlpha',0.8, ...
          'HandleVisibility','off');
    % biên luống
    plot([x1 x1],[y0 y0+dy],'k:','HandleVisibility','off');
    plot([x2 x2],[y0 y0+dy],'k:','HandleVisibility','off');
end

%% ===== VẼ QUỸ ĐẠO & BIÊN ROBOT (MỚI) =====
% --- 1. Vẽ đường biên (minh họa robot rộng 0.35m mỗi bên) ---
w_robot = 0.175; % Khoảng cách từ tâm ra biên

% Tính toán tọa độ biên trái (Left) và phải (Right) dựa trên Theta
% Công thức dịch chuyển vuông góc với hướng di chuyển
xl = x - w_robot * sin(theta);
yl = y + w_robot * cos(theta);

xr = x + w_robot * sin(theta);
yr = y - w_robot * cos(theta);

% Lưu ý: Plot lệnh là plot(truc_ngang, truc_doc) -> plot(y, x)
h_boundary = plot( xl,yl, 'r--', 'LineWidth', 0.8); % Biên trái
plot( xr,yr, 'r--', 'LineWidth', 0.8);              % Biên phải

% --- 2. Vẽ tâm robot (Quỹ đạo chính) ---
h_traj = plot( x, y,'r', 'LineWidth', 2);

%% ===== VẼ HƯỚNG ROBOT =====
step = 30;
u = sin(theta(1:step:end));
v = cos(theta(1:step:end));
h_dir = quiver( x(1:step:end),y(1:step:end), ...
               v, u, 0.35, 'b', 'LineWidth',1);

%% ===== TRANG TRÍ (ÉP MÀU + ÉP TRỤC) =====
xlabel('x(m)', ...
       'FontWeight','bold', ...
       'FontSize',13, ...
       'Color','k');
ylabel('y (m)', ...
       'FontWeight','bold', ...
       'FontSize',13, ...
       'Color','k');
title('Quỹ đạo robot phun thuốc', ...
      'FontWeight','bold', ...
      'FontSize',15, ...
      'Color','k');

% Cập nhật Legend để giải thích đường nét đứt
legend([h_traj h_boundary h_dir], ...
       {'Tâm robot', 'Biên robot (\pm 0.175m)', 'Hướng robot'}, ...
       'Location','best', ...
       'TextColor','k', ...
       'EdgeColor','k', ...
       'Color','w');

% ===== ÉP TRỤC & ÉP MÀU =====
set(gca, ...
    'FontSize',12, ...
    'FontWeight','bold', ...
    'LineWidth',1.4, ...
    'XColor','k', ...
    'YColor','k', ...
    'GridColor',[0 0 0], ...
    'GridAlpha',0.15, ...
    'MinorGridAlpha',0.1);
%% ===== HIỂN THỊ TRỤC ĐÚNG (2D – KHÔNG VIEW) =====
set(gca, ...
    'XAxisLocation','bottom', ...
    'YAxisLocation','left', ...
    'YDir','normal');

%% ===== GIỚI HẠN & HIỂN THỊ DỄ NHÌN (ĐÃ CHỈNH) =====
xlim([0 10]);      % x: bề ngang
ylim([0 52]);      % y: chiều dài

axis normal        % <<< QUAN TRỌNG: bỏ ép hình học cứng
box on
grid off

% --- ÉP TỈ LỆ HIỂN THỊ (nới ngang) ---
pbaspect([3 3 1]);   % x:y = 1:1 nhưng KHÔNG bóp hình

% --- ÉP KÍCH THƯỚC FIGURE (QUAN TRỌNG NHẤT) ---
set(gcf, ...
    'Units','centimeters', ...
    'Position',[2 2 30 16], ...   % <<< RỘNG RA RÕ RỆT
    'Color','w', ...
    'InvertHardcopy','off');
