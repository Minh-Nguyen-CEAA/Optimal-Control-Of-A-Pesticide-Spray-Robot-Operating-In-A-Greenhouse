figure('Color','w')
e123=out.e123;
plot(e123.Time, e123.Data(:,1),'r','LineWidth',1); hold on
plot(e123.Time, e123.Data(:,2),'g','LineWidth',1);
plot(e123.Time, e123.Data(:,3),'b','LineWidth',1);

xlabel('Time (s)','Color','k')
title('e_x, e_y, e_\theta','Color','k')

lgd = legend('e_x (m)','e_y (m)','e_\theta (rad)');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(e123.Time)])   % trục time đúng tới 628