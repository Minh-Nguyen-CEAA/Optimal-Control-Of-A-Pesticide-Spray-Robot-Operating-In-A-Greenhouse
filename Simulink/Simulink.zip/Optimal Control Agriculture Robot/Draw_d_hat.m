figure('Color','w')

d_hat = out.d_hat;

%% ===== DATA =====
t = d_hat.Time;
d = squeeze(d_hat.Data);

%% ===== PLOT =====
plot(t,d,'LineWidth',1.2)
hold on

xlabel('Time (s)','Color','k')

ylabel('$\hat{d}$', ...
    'Interpreter','latex', ...
    'Color','k')

title({'Luật nhiễu'}, ...
    'Interpreter','latex', ...
    'Color','k')

lgd = legend('$\hat{d}_1$','$\hat{d}_2$');
lgd.Interpreter = 'latex';
lgd.Color = 'white';
lgd.TextColor = 'black';
lgd.EdgeColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(t)])