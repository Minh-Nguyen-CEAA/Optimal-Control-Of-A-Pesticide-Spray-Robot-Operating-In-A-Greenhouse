%% TANH_CONST_SPEED_TRAJ.M
% Quy dao hinh vuong: SHAPE = tanh (C-inf) + TOC DO HANG SO v0
% Reparameterize theo arc length → vd = v0 = const moi luc
%
% Uu diem so voi tanh thuong:
%   tanh thuong:      vd thay doi nhieu (nho tai goc)
%   tanh const speed: vd = v0 = hang so → k2*vd*e2 luon active
%
% Dam bao:
%   - Hinh dang C-inf (tanh)
%   - vd = v0 = const > 0 moi t
%   - wd smooth (C-inf) vi kappa cua tanh la C-inf
%   - Khong if, khong diem noi
%   - k2*vd*e2 = hang so, luon active → e2,e3 duoc bu deu

clear; clc; close all;

%% ============================================================
%  THAM SO
%  ============================================================
L   = 5;        % kich thuoc hinh vuong (m)
n   = 5;        % do vuong
v0  = 0.12;     % toc do hang so (m/s)
dth = 1e-5;     % buoc theta cho reparameterize (nho = chinh xac)
dt  = 0.001;    % buoc thoi gian output (s)

%% ============================================================
%  BUOC 1: Tao tanh curve voi theta deu
%  ============================================================
theta_fine = (0 : dth : 2*pi)';
Nth = length(theta_fine);

ct = cos(theta_fine);
st = sin(theta_fine);

% Vi tri
x_fine = L * tanh(n * ct);
y_fine = L * tanh(n * st);

% Dao ham theo theta (analytic)
sc2_c = 1 ./ cosh(n*ct).^2;
sc2_s = 1 ./ cosh(n*st).^2;
tc    = tanh(n*ct);
ts    = tanh(n*st);

dxdth = -L*n.*st.*sc2_c;      % dx/dtheta
dydth =  L*n.*ct.*sc2_s;      % dy/dtheta

ddxdth = -L*n*(ct.*sc2_c - 2*n*st.^2.*tc.*sc2_c);  % d2x/dtheta2
ddydth = -L*n*(st.*sc2_s + 2*n*ct.^2.*ts.*sc2_s);  % d2y/dtheta2

% Toc do theo theta (ds/dtheta)
dsdth = sqrt(dxdth.^2 + dydth.^2);   % |dr/dtheta|

%% ============================================================
%  BUOC 2: Tinh arc length s(theta)
%  ============================================================
s_fine = [0; cumsum(dsdth(1:end-1) * dth)];
S_total = s_fine(end);
T_total = S_total / v0;

fprintf('=== TANH CONST SPEED ===\n');
fprintf('Tong arc length  = %.4f m\n', S_total);
fprintf('Toc do v0        = %.4f m/s\n', v0);
fprintf('Tong thoi gian T = %.2f s\n', T_total);

%% ============================================================
%  BUOC 3: Reparameterize — tim theta(s) qua interp1
%  Voi toc do hang so: s = v0*t → t = s/v0
%  ============================================================
t_out  = (0 : dt : T_total)';
s_out  = v0 * t_out;              % s tuong ung voi moi t

% Noi suy theta tu s (tranh phan tu trung lap trong s_fine)
[s_unique, idx_u] = unique(s_fine);
theta_out = interp1(s_unique, theta_fine(idx_u), s_out, 'pchip');

%% ============================================================
%  BUOC 4: Tinh tat ca tin hieu tai theta_out
%  ============================================================
ct2 = cos(theta_out);
st2 = sin(theta_out);
sc2_c2 = 1 ./ cosh(n*ct2).^2;
sc2_s2 = 1 ./ cosh(n*st2).^2;
tc2    = tanh(n*ct2);
ts2    = tanh(n*st2);

% Vi tri
xd = L * tc2;
yd = L * ts2;

% Goc huong
% dx/dtheta va dy/dtheta tai theta_out
dxdth2 = -L*n.*st2.*sc2_c2;
dydth2 =  L*n.*ct2.*sc2_s2;

% Goc huong = atan2(dy/dt, dx/dt) = atan2(dy/dtheta, dx/dtheta)
% (vi dtheta/dt > 0 nen dau khong doi)
thetad = unwrap(atan2(dydth2, dxdth2));

% Toc do dai = v0 (hang so theo thiet ke)
vd = v0 * ones(size(t_out));

% Van toc goc: wd = kappa * v0
% kappa = (x'*y'' - y'*x'') / (x'^2 + y'^2)^(3/2)   [theo theta]
% Nhung voi arc-length param: wd = (dxdt*d2ydt2 - dydt*d2xdt2) / vd^2
% = kappa_theta * dtheta/dt * v0 = kappa_theta * (v0/dsdth) * v0
%   dsdth tai theta_out:
dsdth2 = sqrt(dxdth2.^2 + dydth2.^2);

% d2x/dtheta2, d2y/dtheta2 tai theta_out
ddxdth2 = -L*n*(ct2.*sc2_c2 - 2*n*st2.^2.*tc2.*sc2_c2);
ddydth2 = -L*n*(st2.*sc2_s2 + 2*n*ct2.^2.*ts2.*sc2_s2);

% Curvature theo theta-parameterization
kappa = (dxdth2.*ddydth2 - dydth2.*ddxdth2) ./ (dsdth2.^3 + 1e-12);

% wd = kappa * v0  (vi vd = v0 = const)
wd = kappa * v0;

% dvd = 0 (v0 hang so)
dvd = zeros(size(t_out));

% dwd = d(kappa)/dt * v0 = d(kappa)/ds * v0^2
dkds = [0; diff(kappa) ./ (v0*dt)];   % d(kappa)/dt / v0 ... 
dwd  = [0; diff(wd)/dt];
% Lam smooth dwd (finite diff co noise)
win = 51;
dwd = movmean(dwd, win);

%% ============================================================
%  KIEM TRA
%  ============================================================
fprintf('\n=== KIEM TRA ===\n');
fprintf('Min vd        = %.6f m/s  (= v0, phai hang so)\n', min(vd));
fprintf('Max vd        = %.6f m/s\n', max(vd));
fprintf('Max |wd|      = %.4f rad/s\n', max(abs(wd)));
fprintf('Max |dwd|     = %.4f rad/s^2\n', max(abs(dwd)));
fprintf('Max jump wd   = %.2e (nen rat nho)\n', max(abs(diff(wd))));
fprintf('Max jump xd   = %.2e\n', max(abs(diff(xd))));

%% ============================================================
%  LUU CHO SIMULINK
%  ============================================================
traj.t       = t_out;
traj.xd      = xd;
traj.yd      = yd;
traj.thetad  = thetad;
traj.vd      = vd;
traj.wd      = wd;
traj.dvd     = dvd;
traj.dwd     = dwd;
traj.T_total = T_total;
traj.v0      = v0;

save('tanh_const_speed_data.mat', 'traj');
fprintf('Da luu: tanh_const_speed_data.mat\n');

%% ============================================================
%  VE DO THI
%  ============================================================
figure('Name','Tanh Const Speed','Position',[40 40 1300 800],'Color','w');
lw = 1.5;
blue   = [0.13 0.45 0.80];
red    = [0.85 0.20 0.20];
green  = [0.13 0.65 0.35];

% 1. XY
subplot(2,3,1);
plot(xd, yd, 'Color', blue, 'LineWidth', lw);
hold on;
plot(xd(1), yd(1), 'go', 'MarkerSize', 10, 'LineWidth', 2);
axis equal; grid on; grid minor;
xlabel('x (m)'); ylabel('y (m)');
title('Qu\~{y} \dj{}ao XY (tanh shape, const speed)');

% 2. vd -- phai PHANG TUYET DOI
subplot(2,3,2);
plot(t_out, vd, 'Color', blue, 'LineWidth', lw);
ylim([0, v0*1.5]);
yline(v0, 'r--', 'LineWidth', 1.5, 'Label', sprintf('v0=%.3f',v0));
xlabel('t (s)'); ylabel('v_d (m/s)');
title('v_d(t) = v_0 = HANG SO  ✓');
grid on; grid minor;

% 3. wd
subplot(2,3,3);
plot(t_out, wd, 'Color', red, 'LineWidth', lw);
yline(0, 'k--', 'LineWidth', 0.8);
xlabel('t (s)'); ylabel('\omega_d (rad/s)');
title('\omega_d(t) = \kappa(s) \cdot v_0  (smooth)');
grid on; grid minor;

% 4. kappa
subplot(2,3,4);
plot(t_out, kappa, 'Color', green, 'LineWidth', lw);
yline(0, 'k--', 'LineWidth', 0.8);
xlabel('t (s)'); ylabel('\kappa (1/m)');
title('Curvature \kappa(t) — C^\infty');
grid on; grid minor;

% 5. dvd -- phai = 0
subplot(2,3,5);
plot(t_out, dvd, 'Color', blue, 'LineWidth', lw);
ylim([-0.01, 0.01]);
xlabel('t (s)'); ylabel('dv_d/dt');
title('dv_d/dt = 0  (v_0 = const)  ✓');
grid on; grid minor;

% 6. dwd
subplot(2,3,6);
plot(t_out, dwd, 'Color', red, 'LineWidth', lw);
yline(0, 'k--', 'LineWidth', 0.8);
xlabel('t (s)'); ylabel('d\omega_d/dt');
title('d\omega_d/dt');
grid on; grid minor;

sgtitle(sprintf(['Tanh Const Speed  |  L=%.0fm  n=%.0f  ' ...
                 'v_0=%.3fm/s  T=%.1fs'], L, n, v0, T_total), ...
        'FontSize', 12, 'FontWeight', 'bold');

%% ============================================================
%  SO SANH vd: tanh thuong vs tanh const speed
%  ============================================================
figure('Name','So sanh vd','Position',[60 60 900 400],'Color','w');

% tanh thuong
dth_cmp   = 2*pi/T_total;
theta_cmp = dth_cmp * t_out;
dxd_cmp   = -L*n.*sin(theta_cmp)./cosh(n*cos(theta_cmp)).^2 * dth_cmp;
dyd_cmp   =  L*n.*cos(theta_cmp)./cosh(n*sin(theta_cmp)).^2 * dth_cmp;
vd_cmp    = sqrt(dxd_cmp.^2 + dyd_cmp.^2);

plot(t_out, vd_cmp, 'r-', 'LineWidth', 1.5, 'DisplayName', 'tanh th\^{o}ng th\`{u}ong'); 
hold on;
plot(t_out, vd,     'b-', 'LineWidth', 1.5, 'DisplayName', 'tanh const speed');
yline(v0, 'k--', 'LineWidth', 1, 'Label', 'v_0');
xlabel('t (s)'); ylabel('v_d (m/s)');
title('So sanh');
legend('Location','best'); grid on; grid minor;