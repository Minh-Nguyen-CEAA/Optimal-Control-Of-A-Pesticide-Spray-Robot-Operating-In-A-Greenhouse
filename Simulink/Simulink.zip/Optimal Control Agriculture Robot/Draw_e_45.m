figure('Color','w')
e45=out.e45;
plot(e45.Time, e45.Data(:,1),'r','LineWidth',1); hold on
plot(e45.Time, e45.Data(:,2),'b','LineWidth',1);

xlabel('Time (s)','Color','k')
title('e_{(v-v_c)}, e_{(\omega-\omega_c)}','Color','k')

lgd = legend('e_{(v-v_c)} (m)','e_{(\omega-\omega_c)} (rad)');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(e45.Time)])   % trục time đúng tới 628