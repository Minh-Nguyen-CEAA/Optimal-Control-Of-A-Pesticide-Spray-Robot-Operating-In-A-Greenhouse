tau   = out.tau;
tau_c = out.tau_c;
u_hat    = out.u_hat;

t  = tau.Time;

u_tau   = squeeze(tau.Data);
u_tauc  = squeeze(tau_c.Data);
u_hat  = squeeze(u_hat.Data);

figure('Color','w')

%% ---- tau_c ----
subplot(3,1,1)

plot(t,u_tauc(:,1),'r','LineWidth',1); hold on
plot(t,u_tauc(:,2),'b','LineWidth',1)

title('$\tau_c$','Interpreter','latex','Color','k')

lgd = legend('$\tau_{cR}$','$\tau_{cL}$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])


%% ---- u_hat ----
subplot(3,1,2)

plot(t,u_hat(1,:).','r','LineWidth',1); hold on
plot(t,u_hat(2,:).','b','LineWidth',1)
title('$\hat{u}$','Interpreter','latex','Color','k')

lgd = legend('$\hat{u}_R$','$\hat{u}_L$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])


%% ---- tau ----
subplot(3,1,3)

plot(t,u_tau(1,:),'r','LineWidth',1); hold on
plot(t,u_tau(2,:),'b','LineWidth',1)

title('$\tau$','Interpreter','latex','Color','k')
xlabel('Time (s)','Color','k')

lgd = legend('$\tau_R$','$\tau_L$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])