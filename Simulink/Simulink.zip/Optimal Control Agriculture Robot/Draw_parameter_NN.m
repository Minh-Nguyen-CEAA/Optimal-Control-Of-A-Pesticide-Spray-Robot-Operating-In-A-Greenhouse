Weight__NN = out.Weight_NN;

t = out.tout;      % thời gian mô phỏng
w = Weight__NN;    % dữ liệu double

figure('Color','w')

plot(t,w(:,1),'r','LineWidth',1.5); hold on
plot(t,w(:,2),'b','LineWidth',1.5);
plot(t,w(:,3),'g','LineWidth',1.5);

xlabel('Time (s)','Color','k')

title('Parameters of the NN ($\hat{W}$)', ...
    'Interpreter','latex', ...
    'Color','k')

lgd = legend('W_1','W_2','W_3');
lgd.Color = 'white';
lgd.TextColor = 'black';

grid on
set(gca,'Color','w','XColor','k','YColor','k')

xlim([0 max(t)])