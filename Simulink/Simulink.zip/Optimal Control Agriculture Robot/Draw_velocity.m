vd = out.vd;
vc = out.vc;
v  = out.v;

t = vd.Time;

% ---- chuẩn hóa dữ liệu về dạng N×2 ----
vd_data = squeeze(vd.Data);
vc_data = squeeze(vc.Data);
v_data  = squeeze(v.Data);

%% ================= Figure 1: vd vc =================
figure('Color','w')

subplot(2,1,1)

plot(t,vd_data(:,1),'r','LineWidth',1); hold on
plot(t,vc_data(:,1),'b','LineWidth',1)

title('$v_d , v_c$','Interpreter','latex','Color','k')
lgd=legend('$v_d$','$v_c$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])


subplot(2,1,2)

plot(t,vd_data(:,2),'r','LineWidth',1); hold on
plot(t,vc_data(:,2),'b','LineWidth',1)

title('$\omega_d , \omega_c$','Interpreter','latex','Color','k')
xlabel('Time (s)')

lgd=legend('$\omega_d$','$\omega_c$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])



%% ================= Figure 2: vd v =================
figure('Color','w')

subplot(2,1,1)

plot(t,vd_data(:,1),'r','LineWidth',1); hold on
plot(t,v_data(1,:),'b','LineWidth',1)

title('$v_d , v$','Interpreter','latex','Color','k')

lgd=legend('$v_d$','$v$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])


subplot(2,1,2)

plot(t,vd_data(:,2),'r','LineWidth',1); hold on
plot(t,v_data(2,:),'b','LineWidth',1)

title('$\omega_d , \omega$','Interpreter','latex','Color','k')
xlabel('Time (s)')

lgd=legend('$\omega_d$','$\omega$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])
%% ================= Figure 2: vc v =================
figure('Color','w')

subplot(2,1,1)

plot(t,vc_data(:,1),'r','LineWidth',1); hold on
plot(t,v_data(1,:),'b','LineWidth',1)

title('$v_c , v$','Interpreter','latex','Color','k')

lgd=legend('$v_c$','$v$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])


subplot(2,1,2)

plot(t,vc_data(:,2),'r','LineWidth',1); hold on
plot(t,v_data(2,:),'b','LineWidth',1)

title('$\omega_c , \omega$','Interpreter','latex','Color','k')
xlabel('Time (s)')

lgd=legend('$\omega_c$','$\omega$','Interpreter','latex');
lgd.Color = 'white';
lgd.TextColor = 'black';
grid on
set(gca,'Color','w','XColor','k','YColor','k')
xlim([0 t(end)])